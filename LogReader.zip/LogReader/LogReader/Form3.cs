﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogReader
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        int LastRowIndex;
        private void btn_Looping_Click(object sender, EventArgs e)
        {
            // Get LastRowIndex
            for (int i = 0; i < 10000; i++)
            {
                if (spreadsheetControl1.ActiveWorksheet.Columns[0][i].Value.ToString() == "")
                {
                    LastRowIndex = i;
                    break;
                }
            }


            //row Looping
            for (int i = 0; i < LastRowIndex; i++)
            {
                MessageBox.Show(spreadsheetControl1.ActiveWorksheet.Columns[0][i].Value.ToString());
            }


        }

        private void btn_Browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    spreadsheetControl1.LoadDocument(ofd.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
