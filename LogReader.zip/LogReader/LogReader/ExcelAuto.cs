﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;

namespace LogReader
{
    public class ExcelAuto
    {
        //  Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
        Excel.Workbooks wbs;
        _Workbook iwb;
        Excel.Sheets sh;
        _Worksheet iws;

        private Excel.Application ExcelApp;
        private Excel.Workbooks objBooks;
        private Excel.Workbook objBook;
        private Excel.Worksheet objSheet;
        private Excel.Range range;

        string strAttendeeList, strAbsenteeList, strCopiesToList;
        int totActionItems;
        object oMissing, oTemplate;
        private string strTitle;

        public ExcelAuto()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public void CreateFile(ArrayList array)
        {
            object missing = System.Reflection.Missing.Value;
            object fileName = "normal.dot";
            object newTemplate = false;
            object docType = 0;
            object isVisible = true;

            ExcelApp = new Excel.ApplicationClass();
            ExcelApp.Visible = true;
            objBook = ExcelApp.Workbooks.Add(missing);
            objSheet = (Excel.Worksheet)objBook.Sheets["Sheet1"];
            objSheet.Name = "It's Me";

            objSheet.Cells[1, 1] = "Details";
            objSheet.Cells[2, 1] = "Name : " + array[0].ToString();
            objSheet.Cells[3, 1] = "Age : " + array[1].ToString();
            objSheet.Cells[4, 1] = "Designation : " + array[2].ToString();
            objSheet.Cells[5, 1] = "Company : " + array[3].ToString();
            objSheet.Cells[6, 1] = "Place : " + array[4].ToString();
            objSheet.Cells[7, 1] = "Email : " + array[5].ToString();

            objSheet.get_Range("A1", "A1").Font.Bold = true;
            objSheet.get_Range("A1", "A6").EntireColumn.AutoFit();
            objSheet.get_Range("A1", "A7").BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlMedium,
            Excel.XlColorIndex.xlColorIndexAutomatic, Excel.XlColorIndex.xlColorIndexAutomatic);

            objSheet.get_Range("C1", "C1").Validation.Add(Microsoft.Office.Interop.Excel.XlDVType.xlValidateList, Microsoft.Office.Interop.Excel.XlDVAlertStyle.xlValidAlertInformation, Excel.XlFormatConditionOperator.xlBetween, ("=$A$1:$A$5"), ("A4"));
            objSheet.Cells[5, 5] = "karim";
        }

        public void CreateNewFile(System.Windows.Forms.DataGridView dataGridView1, Boolean SavePassword, string Password, Boolean With_Data)
        {
            object missing = System.Reflection.Missing.Value;
            object fileName = "normal.dot";
            object newTemplate = false;
            object docType = 0;
            object isVisible = true;

            ExcelApp = new Excel.ApplicationClass();
            ExcelApp.Visible = true;

            objBook = ExcelApp.Workbooks.Add(missing);

            if (SavePassword == true)
            {
                objBook.Password = Password;
            }

            objSheet = (Excel.Worksheet)objBook.Sheets["Sheet1"];
            objSheet.Name = dataGridView1.Rows[0].Cells[0].Value.ToString();

            //objSheet.get_Range("A1:XFD1048576", Type.Missing).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Gray);


            int count = 1;

            try
            {
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {

                    // objSheet.get_Range(objSheet.Cells[1, count], objSheet.Cells[1048576, count]).Locked = "False";
                    objSheet.get_Range(objSheet.Cells[1, count], objSheet.Cells[objSheet.Rows.Count, count]).Locked = "False";

                    objSheet.Cells[1, count] = dataGridView1.Rows[i].Cells[0].Value.ToString();
                    objSheet.Cells[2, count] = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    objSheet.Cells[3, count] = dataGridView1.Rows[i].Cells[2].Value.ToString();
                    objSheet.Cells[4, count] = dataGridView1.Rows[i].Cells[4].Value.ToString();
                    objSheet.Cells[5, count] = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    objSheet.Cells[6, count] = dataGridView1.Rows[i].Cells[6].Value.ToString();
                    objSheet.Cells[7, count] = dataGridView1.Rows[i].Cells[7].Value.ToString();
                    objSheet.Cells[8, count] = dataGridView1.Rows[i].Cells[8].Value.ToString();
                    objSheet.Cells[9, count] = dataGridView1.Rows[i].Cells[9].Value.ToString();
                    objSheet.Cells[10, count] = dataGridView1.Rows[i].Cells[3].Value.ToString();

                    objSheet.get_Range(objSheet.Cells[10, count], objSheet.Cells[10, count]).Locked = "True";
                    if (dataGridView1.Rows[i].Cells[4].Value.ToString() == "List")
                    {
                        string SQL = "SELECT " + dataGridView1.Rows[i].Cells[6].Value.ToString() + " FROM " + dataGridView1.Rows[i].Cells[7].Value.ToString() + " WHERE (" + dataGridView1.Rows[i].Cells[6].Value.ToString() + "  IS NOT NULL)  ";
                        if (dataGridView1.Rows[i].Cells[8].Value.ToString() != "")
                        {
                            SQL += "AND " + dataGridView1.Rows[i].Cells[8].Value.ToString();
                        }

                        DataSet DS = DB.Execute(SQL);

                        int index = 1;
                        for (int j = 0; j < DS.Tables[0].Rows.Count; j++)
                        {
                            objSheet.Cells[index, count + 1000] = DS.Tables[0].Rows[j][0].ToString();
                            index++;
                        }

                        objSheet.get_Range(objSheet.Cells[10, count], objSheet.Cells[5000, count]).Validation.Add(Microsoft.Office.Interop.Excel.XlDVType.xlValidateList, Microsoft.Office.Interop.Excel.XlDVAlertStyle.xlValidAlertInformation, Excel.XlFormatConditionOperator.xlBetween, ("=$" + GetExcelColumnName(count + 1000) + "$1:$" + GetExcelColumnName(count + 1000) + "$" + index + ""), ("A4"));
                    }

                    count++;
                }
            }
            catch (Exception ex)
            {
                //throw;
            }

            //objSheet.get_Range(objSheet.Cells[1, count], "XFD1048576:XFD1048576").Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Gray);
            //objSheet.get_Range(objSheet.Cells[1, count], "XFD1048576:XFD1048576").Locked = "True";
            objSheet.get_Range(objSheet.Cells[1, count], GetExcelColumnName(objSheet.Columns.Count) + objSheet.Rows.Count.ToString() + ":" + GetExcelColumnName(objSheet.Columns.Count) + objSheet.Rows.Count.ToString()).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Gray);
            objSheet.get_Range(objSheet.Cells[1, count], GetExcelColumnName(objSheet.Columns.Count) + objSheet.Rows.Count.ToString() + ":" + GetExcelColumnName(objSheet.Columns.Count) + objSheet.Rows.Count.ToString()).Locked = "True";



            int ColumnNo = count - 1;
            objSheet.Cells[1, 500] = ColumnNo.ToString();

            objSheet.get_Range("A1", "A1").EntireRow.Hidden = true;
            objSheet.get_Range("A2", "A2").EntireRow.Hidden = true;
            objSheet.get_Range("A3", "A3").EntireRow.Hidden = true;
            objSheet.get_Range("A4", "A4").EntireRow.Hidden = true;
            objSheet.get_Range("A5", "A5").EntireRow.Hidden = true;
            objSheet.get_Range("A6", "A6").EntireRow.Hidden = true;
            objSheet.get_Range("A7", "A7").EntireRow.Hidden = true;
            objSheet.get_Range("A8", "A8").EntireRow.Hidden = true;
            objSheet.get_Range("A9", "A9").EntireRow.Hidden = true;



            objSheet.get_Range(objSheet.Cells[10, 1], objSheet.Cells[10, count - 1]).ColumnWidth = 20;

            objSheet.get_Range(objSheet.Cells[10, 1], objSheet.Cells[10, count - 1]).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
            objSheet.get_Range(objSheet.Cells[10, 1], objSheet.Cells[10, count - 1]).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
            //objSheet.get_Range("A10", "Z10").Font.Italic =true;
            //  objSheet.get_Range("A2", "A100").EntireColumn.AutoFit();
            objSheet.get_Range(objSheet.Cells[10, 1], objSheet.Cells[10, count - 1]).BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlMedium, Excel.XlColorIndex.xlColorIndexAutomatic, Excel.XlColorIndex.xlColorIndexAutomatic);

            objSheet.Protect("Fujix", missing, missing, missing, missing, missing, true, missing, missing, missing, missing, missing, missing, true, missing, missing);


            if (With_Data == true)
            {

                string[] Col_Fileds = new string[dataGridView1.Rows.Count];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    Col_Fileds[i] = dataGridView1.Rows[i].Cells[1].Value.ToString();
                }


                DataSet DS = DB.Execute(fn_Select(dataGridView1.Rows[0].Cells[0].Value.ToString(), Col_Fileds));

                for (int i = 0; i < DS.Tables[0].Rows.Count; i++)
                {
                    for (int j = 0; j < DS.Tables[0].Columns.Count; j++)
                    {
                        objSheet.Cells[i + 11, j + 1] = DS.Tables[0].Rows[i][j].ToString();
                    }
                }


            }


        }

        private string GetExcelColumnName(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;
        }

        public void ReadExcelfile(string AppPath, System.Windows.Forms.DataGridView Grid_ColumnHeader, System.Windows.Forms.DataGridView Grid_ColumnData, System.Windows.Forms.TextBox txt_Table, System.Windows.Forms.TextBox txt_ColumnNO, string Password)
        {
            ExcelApp = new Application();
            wbs = ExcelApp.Workbooks;
            // System.Threading.Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            iwb = wbs.Open(AppPath, 0, false, 1, Password, 0, false, 1, 0, 0, 0, 0, 0, 0, 0);
            sh = iwb.Worksheets;
            iws = (_Worksheet)sh.get_Item(1);

            // Read Table name
            txt_Table.Text = (string)iws.get_Range("A1", "A1").Text;

            // Read columns number
            txt_ColumnNO.Text = (string)iws.get_Range(iws.Cells[1, 500], iws.Cells[1, 500]).Text;

            // Read Column Header
            int col = 0;
            try
            {
                col = int.Parse(txt_ColumnNO.Text);
            }
            catch
            {
                throw new Exception("NoColumns");
                return;
            }
            for (int i = 1; i <= col; i++)
            {
                Grid_ColumnHeader.Columns.Add((string)iws.get_Range(iws.Cells[2, i], iws.Cells[2, i]).Text, (string)iws.get_Range(iws.Cells[2, i], iws.Cells[2, i]).Text);
                Grid_ColumnHeader.Columns[i - 1].ReadOnly = true;

                Grid_ColumnData.Columns.Add((string)iws.get_Range(iws.Cells[2, i], iws.Cells[2, i]).Text, (string)iws.get_Range(iws.Cells[2, i], iws.Cells[2, i]).Text);
                Grid_ColumnData.Columns[i - 1].ReadOnly = true;
            }

            for (int j = 1; j <= 10; j++)
            {
                Grid_ColumnHeader.Rows.Add();
                for (int i = 1; i <= col; i++)
                {
                    Grid_ColumnHeader.Rows[j - 1].Cells[i - 1].Value = (string)iws.get_Range(iws.Cells[j, i], iws.Cells[j, i]).Text;
                }
            }

            // Read Column Datae (Body)

            col = int.Parse(txt_ColumnNO.Text);
            for (int j = 11; ; j++)
            {
                Grid_ColumnData.Rows.Add();
                int EmptyCell = 0;
                for (int i = 1; i <= col; i++)
                {
                    if ((string)iws.get_Range(iws.Cells[j, i], iws.Cells[j, i]).Text == "")
                    {
                        EmptyCell++;
                    }
                    Grid_ColumnData.Rows[j - 11].Cells[i - 1].Value = (string)iws.get_Range(iws.Cells[j, i], iws.Cells[j, i]).Text;
                }

                if (col == EmptyCell)
                {
                    Grid_ColumnData.Rows.RemoveAt(Grid_ColumnData.Rows.Count - 1);
                    break;
                }
            }
            // iwb.Save();


            iwb.Close(true, AppPath, 1);

        }

        public string fn_Select(string table, string[] fields)
        {

            if (fields.Length != fields.Length)

                throw new ArgumentException("The number of fields does not match the number of keys.");

            string query = "Select  ";

            for (int i = 0; i < fields.Length; i++)
            {
                query += fields[i];
                if (i != fields.Length - 1)
                {
                    query += " , ";
                }
            }

            query += " FROM " + table;
            return query;

        }

        //****************************************************************************************************************

        public void ReadExcelfile1(string AppPath, System.Windows.Forms.DataGridView Grid_ColumnHeader, System.Windows.Forms.DataGridView Grid_ColumnData, System.Windows.Forms.TextBox txt_Table, System.Windows.Forms.TextBox txt_ColumnNO, string Password)
        {
            ExcelApp = new Application();
            wbs = ExcelApp.Workbooks;
            // System.Threading.Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            iwb = wbs.Open(AppPath, 0, false, 1, Password, 0, false, 1, 0, 0, 0, 0, 0, 0, 0);
            sh = iwb.Worksheets;
            iws = (_Worksheet)sh.get_Item(1);

            // Read Table name
            txt_Table.Text = (string)iws.get_Range("A1", "A1").Text;

            // Read columns number
            txt_ColumnNO.Text = (string)iws.get_Range(iws.Cells[1, 500], iws.Cells[1, 500]).Text;
            string txt_RowNo = (string)iws.get_Range(iws.Cells[2, 500], iws.Cells[2, 500]).Text;

            // Read Column Header
            int col = 0;
            int row = 0;
            try
            {
                col = int.Parse(txt_ColumnNO.Text);
                row = int.Parse(txt_RowNo);

            }
            catch
            {
                throw new Exception("NoColumns");
                return;
            }
            for (int i = 1; i <= col; i++)
            {
                Grid_ColumnHeader.Columns.Add((string)iws.get_Range(iws.Cells[2, i], iws.Cells[2, i]).Text, (string)iws.get_Range(iws.Cells[2, i], iws.Cells[2, i]).Text);
                Grid_ColumnHeader.Columns[i - 1].ReadOnly = true;

                Grid_ColumnData.Columns.Add((string)iws.get_Range(iws.Cells[2, i], iws.Cells[2, i]).Text, (string)iws.get_Range(iws.Cells[2, i], iws.Cells[2, i]).Text);
                Grid_ColumnData.Columns[i - 1].ReadOnly = true;
            }

            for (int j = 1; j <= row; j++)
            {
                Grid_ColumnHeader.Rows.Add();
                for (int i = 1; i <= col; i++)
                {
                    Grid_ColumnHeader.Rows[j - 1].Cells[i - 1].Value = (string)iws.get_Range(iws.Cells[j, i], iws.Cells[j, i]).Text;
                }
            }

            // Read Column Datae (Body)

            col = int.Parse(txt_ColumnNO.Text);
            row++;
            for (int j = row; ; j++)
            {
                Grid_ColumnData.Rows.Add();
                int EmptyCell = 0;
                for (int i = 1; i <= col; i++)
                {
                    if ((string)iws.get_Range(iws.Cells[j, i], iws.Cells[j, i]).Text == "")
                    {
                        EmptyCell++;
                    }
                    Grid_ColumnData.Rows[j - row].Cells[i - 1].Value = (string)iws.get_Range(iws.Cells[j, i], iws.Cells[j, i]).Text;
                }

                if (col == EmptyCell)
                {
                    Grid_ColumnData.Rows.RemoveAt(Grid_ColumnData.Rows.Count - 1);
                    break;
                }
            }
            // iwb.Save();


            iwb.Close(true, AppPath, 1);

        }

        //****************************************************************************************************************

        public void CreateNewFile1(System.Windows.Forms.DataGridView dataGridView1, Boolean SavePassword, string Password, Boolean With_Data)
        {
            object missing = System.Reflection.Missing.Value;
            object fileName = "normal.dot";
            object newTemplate = false;
            object docType = 0;
            object isVisible = true;

            ExcelApp = new Excel.ApplicationClass();
            ExcelApp.Visible = true;

            objBook = ExcelApp.Workbooks.Add(missing);

            if (SavePassword == true)
            {
                objBook.Password = Password;
            }

            objSheet = (Excel.Worksheet)objBook.Sheets["Sheet1"];
            objSheet.Name = dataGridView1.Rows[0].Cells[0].Value.ToString();

            //objSheet.get_Range("A1:XFD1048576", Type.Missing).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Gray);


            //int count = 1;
            int Col_count = 0;
            int Row_count = 0;
            try
            {
                for (Row_count = 0; Row_count < dataGridView1.Rows.Count; Row_count++)
                {
                    for (Col_count = 0; Col_count < dataGridView1.Columns.Count; Col_count++)
                    {
                        try
                        {
                            objSheet.Cells[Col_count + 1, Row_count + 1] = dataGridView1.Rows[Row_count].Cells[Col_count].Value.ToString();
                            objSheet.get_Range(objSheet.Cells[Col_count + 1, Row_count + 1], objSheet.Cells[Col_count + 1, Row_count + 1]).Locked = "True";
                        }
                        catch
                        {
                            objSheet.Cells[Col_count + 1, Row_count + 1] = "";
                        }
                    }

                    // objSheet.get_Range(objSheet.Cells[1,1], objSheet.Cells[Col_count, Row_count]).Locked = "True";

                    if (dataGridView1.Rows[Row_count].Cells[4].Value.ToString() == "List")
                    {
                        string SQL = "SELECT " + dataGridView1.Rows[Row_count].Cells[6].Value.ToString() + " FROM " + dataGridView1.Rows[Row_count].Cells[7].Value.ToString() + " WHERE (" + dataGridView1.Rows[Row_count].Cells[6].Value.ToString() + "  IS NOT NULL)  ";

                        if (dataGridView1.Rows[Row_count].Cells[8].Value.ToString() != "")
                        {
                            SQL += "AND " + dataGridView1.Rows[Row_count].Cells[8].Value.ToString();
                        }

                        DataSet DS = DB.Execute(SQL);

                        int index = 1;
                        for (int j = 0; j < DS.Tables[0].Rows.Count; j++)
                        {
                            objSheet.Cells[index, Row_count + 1 + 1000] = DS.Tables[0].Rows[j][0].ToString();
                            index++;
                        }

                        objSheet.get_Range(objSheet.Cells[Col_count + 1, Row_count + 1], objSheet.Cells[objSheet.Columns.Count, Row_count + 1]).Validation.Add(Microsoft.Office.Interop.Excel.XlDVType.xlValidateList, Microsoft.Office.Interop.Excel.XlDVAlertStyle.xlValidAlertInformation, Excel.XlFormatConditionOperator.xlBetween, ("=$" + GetExcelColumnName(Row_count + 1 + 1000) + "$1:$" + GetExcelColumnName(Row_count + 1 + 1000) + "$" + index + ""), ("A4"));
                    }


                    //count++;
                }
            }
            catch (Exception ex)
            {
                throw;
            }


            //count = 10;


            objSheet.get_Range(objSheet.Cells[1, Row_count + 1], GetExcelColumnName(objSheet.Columns.Count) + objSheet.Rows.Count.ToString() + ":" + GetExcelColumnName(objSheet.Columns.Count) + objSheet.Rows.Count.ToString()).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Gray);
            objSheet.get_Range(objSheet.Cells[1, Row_count + 1], GetExcelColumnName(objSheet.Columns.Count) + objSheet.Rows.Count.ToString() + ":" + GetExcelColumnName(objSheet.Columns.Count) + objSheet.Rows.Count.ToString()).Locked = "True";


            objSheet.get_Range(objSheet.Cells[Row_count + 1, 1], objSheet.Cells[objSheet.Rows.Count, Row_count]).Locked = "False";

            int ColumnNo = Row_count;
            int RowNo = Col_count;
            objSheet.Cells[1, 500] = ColumnNo.ToString();
            objSheet.Cells[2, 500] = RowNo.ToString();

            for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
            {
                if (i != 4)
                {
                    //   Letter = GetExcelColumnName(i + 1);

                    //objSheet.get_Range(Letter + i.ToString(), Letter + i.ToString()).EntireRow.Hidden = true;

                    objSheet.get_Range(objSheet.Cells[i, i], objSheet.Cells[i, i]).EntireRow.Hidden = true;

                }
            }

            objSheet.get_Range(objSheet.Cells[4, 1], objSheet.Cells[4, Row_count]).ColumnWidth = 20;
            objSheet.get_Range(objSheet.Cells[4, 1], objSheet.Cells[4, Row_count]).Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
            objSheet.get_Range(objSheet.Cells[4, 1], objSheet.Cells[4, Row_count]).Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
            objSheet.get_Range(objSheet.Cells[4, 1], objSheet.Cells[4, Row_count]).BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlMedium, Excel.XlColorIndex.xlColorIndexAutomatic, Microsoft.Office.Interop.Excel.XlColorIndex.xlColorIndexAutomatic);
            objSheet.Protect("Fujix", missing, missing, missing, missing, missing, true, missing, missing, missing, missing, missing, missing, true, missing, missing);


            if (With_Data == true)
            {

                string[] Col_Fileds = new string[dataGridView1.Rows.Count];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    Col_Fileds[i] = dataGridView1.Rows[i].Cells[1].Value.ToString();
                }


                DataSet DS = DB.Execute(fn_Select(dataGridView1.Rows[0].Cells[0].Value.ToString(), Col_Fileds));

                for (int i = 0; i < DS.Tables[0].Rows.Count; i++)
                {
                    for (int j = 0; j < DS.Tables[0].Columns.Count; j++)
                    {
                        objSheet.Cells[i + 11, j + 1] = DS.Tables[0].Rows[i][j].ToString();
                    }
                }


            }


        }


        public void fn_openfile(string AppPath)
        {
            ExcelApp = new Application();
            wbs = ExcelApp.Workbooks;
            // System.Threading.Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            iwb = wbs.Open(AppPath, 0, false, 1, "", 0, false, 1, 0, 0, 0, 0, 0, 0, 0);
            sh = iwb.Worksheets;
            iws = (_Worksheet)sh.get_Item(1);
        }

        public void fn_Closefile(string AppPath)
        {
            iwb.Close(true, AppPath, 1);
        }


        public DataSet Read()
        {
            DataSet ds = new DataSet();
            System.Data.DataTable dt = new System.Data.DataTable();
            DataColumn dc1 = new DataColumn("size");
            DataColumn dc2 = new DataColumn("qty");
            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            ds.Tables.Add(dt);

            for (int i = 791; i <= 858; i++)
            {

                ds.Tables[0].Rows.Add(new string[] { (string)iws.get_Range("A" + i.ToString(), "A" + i.ToString()).Value2.ToString(), (string)iws.get_Range("B" + i.ToString(), "B" + i.ToString()).Value2.ToString() });
            }
            return ds;
        }

    }
}
